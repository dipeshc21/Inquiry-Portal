<?php

return [
    'name' => env('APP_NAME', 'Inquiry Management Portal'),

    'env' => env('APP_ENV', 'production'),

    'debug' => (bool) env('APP_DEBUG', false),

    'url' => env('APP_URL', 'http://localhost:8000'),

    'frontend_url' => env('FRONTEND_URL', 'http://localhost:5173'),

    'timezone' => env('APP_TIMEZONE', 'UTC'),

    'locale' => env('APP_LOCALE', 'en'),

    'fallback_locale' => env('APP_FALLBACK_LOCALE', 'en'),

    'faker_locale' => env('APP_FAKER_LOCALE', 'en_US'),

    'cipher' => 'AES-256-CBC',

    'key' => env('APP_KEY'),

    'previous_keys' => array_values(array_filter(
        explode(',', (string) env('APP_PREVIOUS_KEYS', ''))
    )),

    'maintenance' => [
        'driver' => 'file',
        'store' => 'database',
    ],
];
